package com.walletApplication.bean;

public class Wallet {

	private String Name;
	private Long AccountNo;
	private String AccountType;
	private String PhoneNo;
	private String Address;
	private String AdhaarNo;
	private String Email;
	private double Balance;
	private String Age;
	private String Pin;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Long getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(Long accountNo) {
		AccountNo = accountNo;
	}
	public String getAccountType() {
		return AccountType;
	}
	public void setAccountType(String accountType) {
		AccountType = accountType;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getAdhaarNo() {
		return AdhaarNo;
	}
	public void setAdhaarNo(String adhaarNo) {
		AdhaarNo = adhaarNo;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getPin() {
		return Pin;
	}
	public void setPin(String pin) {
		Pin = pin;
	}
	public Wallet( Long accountNo,String name, String accountType, String phoneNo, String address, String adhaarNo,
			String email, double balance, String age, String pin) {
		super();
		AccountNo = accountNo;
		Name = name;
		
		AccountType = accountType;
		PhoneNo = phoneNo;
		Address = address;
		AdhaarNo = adhaarNo;
		Email = email;
		Balance = balance;
		Age = age;
		Pin = pin;
	}
	public Wallet() {
		// TODO Auto-generated constructor stub
	}
	

}
